def bot():
    x = input("Enter Your Name")
    print(x)

bot()
